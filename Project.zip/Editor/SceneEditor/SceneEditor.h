#pragma once
#include <vector>
#include <memory>
#include "Engine/Asset/Resource/Resource.h"
#include "Engine/Scene/BaseScene/BaseScene.h"
#include <Externals/nlohmann/json.hpp>

#ifdef USE_IMGUI
#include "imgui_stdlib.h"
#include "GizmoCtx.h"
#endif

class SceneEditor {
public:
	SceneEditor();
	void Update();
	void Draw(Camera* camera);

	void DrawInspector(SceneObject* object);

	void Save();
	void Load(const std::string& path, Vector3 offset = Vector3{0,0,0});

	std::string SerializeScene();
	void DeserializeScene(const std::string& jsonText);

	BaseScene* scene_;
#ifdef USE_IMGUI
	GizmoCtx gizmoCtx_{};
#endif
private:
	void PushUndo();
	void Undo();
	void Redo();

	// 選択
	void ClickSelect();

	// 最後に操作したファイル更新
	void SaveLastFileName();

	std::vector<std::unique_ptr<Resource>> resources_;
	SceneObject* selected_;
	std::string selectedAssetDir_[3] = { "Resources/Debug/whiteCube", "Resources/Models/block", "Resources/Models/Floor",};
	std::string selectedAssetPath_[3] = { "whiteCube.obj", "block.obj", "floor.obj" };
	int selectedAssetIndex_ = 0;
	int gizmoMode_ = 0;

	std::vector<std::string> undoStack_;
	std::vector<std::string> redoStack_;
	bool wasUsing_ = false;

	bool useSnap_ = false;
	float moveSnap_ = 1.0f;
	float rotateSnap_ = std::numbers::pi_v<float> / 4.0f;
	float scaleSnap_ = 0.1f;

	int editingInstance_ = 0;

	bool undoRequest_ = false;
	bool redoRequest_ = false;

	int addInstanceNum_ = 1;

	// ファイルパス
	std::string currentFileName_ = "SceneData";
};

