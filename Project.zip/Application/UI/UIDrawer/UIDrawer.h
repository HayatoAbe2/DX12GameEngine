#pragma once
#include "UI/Equipment/EquipmentUI.h"
#include "UI/Money/MoneyUI.h"
#include "UI/NextRoom/NextRoomUI.h"
#include "UI/Passive/PassiveUI.h"
#include "UI/WeaponSummary/WeaponSummary.h"
#include "Map/Room/RoomData.h"

class Player;
class FloorManager;
class ItemManager;

/// <summary>
/// UI描画
/// </summary>
class UIDrawer {
public:
	UIDrawer(Player* player, FloorManager* floorManager, ItemManager* itemManager);
	// 更新
	void Update();
	// 描画
	void Draw();

	// プレイヤーUI(所持アイテムなど)
	void UpdatePlayerUI();
	// ステージUI(進捗)
	void UpdateStageUI();

private:
	Player* player_;
	ItemManager* itemManager_;

	struct SpriteData {
		Vector2 pos;
		Vector2 size;
	};

	// hp
	std::unique_ptr<Sprite> life_ = nullptr;
	std::unique_ptr<Sprite> damage_ = nullptr; // 減った分
	std::unique_ptr<Sprite> lifeBack_ = nullptr;
	float whiteLife_ = 0;
	float whiteGaugeSpeed_ = 0.5f;
	// 数値
	std::array<std::unique_ptr<Sprite>, 4> numbers_;

	std::unique_ptr<EquipmentUI> equipment_;
	// 弾数
	std::unique_ptr<Sprite> ammo_ = nullptr;
	std::unique_ptr<Sprite> magazine_ = nullptr;
	SpriteData ammoUIData_ = { {640,380}, {100,22} }; 

	std::unique_ptr<Sprite> dodgeControlKey_ = nullptr;
	std::unique_ptr<Sprite> dodgeControlPad_ = nullptr;
	SpriteData dodgeControlUIData_ = { {1110,360}, { 50, 50 } };
	std::unique_ptr<Sprite> dodge_ = nullptr;
	SpriteData dodgeUIData_ = { {1171,358}, { 80, 53.3f } };

	// 階数
	std::unique_ptr<Sprite> currentFloor_ = nullptr;
	SpriteData floorUIData_ = { {640,320}, { 212,32 } };

	std::unique_ptr<MoneyUI> money_;
	std::unique_ptr<NextRoomUI> nextRoom_;
	std::unique_ptr<PassiveUI> passive_;
	std::unique_ptr<WeaponSummaryUI> weaponSummary_;
};

