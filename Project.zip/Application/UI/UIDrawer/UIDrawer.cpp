#include "UIDrawer.h"
#include "Objects/Character/Player/Player.h"
#include "Objects/Item/ItemManager.h"
#include <Objects/Item/World/WorldWeapon/WorldWeapon.h>

UIDrawer::UIDrawer(Player* player, FloorManager* floorManager, ItemManager* itemManager) : player_(player), itemManager_(itemManager) {
	money_ = std::make_unique<MoneyUI>(player_->GetWallet());
	nextRoom_ = std::make_unique<NextRoomUI>(floorManager);
	passive_ = std::make_unique<PassiveUI>(player);
	weaponSummary_ = std::make_unique<WeaponSummaryUI>();

	equipment_ = std::make_unique<EquipmentUI>();
	equipment_->Initialize(player);

	auto& ctx = GameContext::GetInstance();
	auto& asset = ctx.Asset();

#pragma region PlayerUI
	life_ = asset.LoadSprite("Resources/Images/UI/gauge.png");
	life_->SetSize({ 290,68 });
	life_->SetPosition({ 10,10 });
	damage_ = asset.LoadSprite("Resources/Debug/white1x1.png");
	damage_->SetSize({ 290,68 });
	damage_->SetPosition({ 10,10 });
	lifeBack_ = asset.LoadSprite("Resources/Images/UI/gauge.png");
	lifeBack_->SetSize({ 290,68 });
	lifeBack_->SetPosition({ 10,10 });
	lifeBack_->SetColor({ 0.2f,0.2f,0.2f,1 });

#pragma endregion

	dodgeControlKey_ = asset.LoadSprite("Resources/Images/Control/KeyboardAndMouse.dds");
	dodgeControlKey_->SetSize(dodgeControlUIData_.size);
	dodgeControlKey_->SetPosition(dodgeControlUIData_.pos);
	dodgeControlKey_->SetTextureRect(64 * 16, 64 * 4, 64, 64);
	dodgeControlPad_ = asset.LoadSprite("Resources/Images/Control/XboxController.dds");
	dodgeControlPad_->SetSize(dodgeControlUIData_.size);
	dodgeControlPad_->SetPosition(dodgeControlUIData_.pos);
	dodgeControlPad_->SetTextureRect(64 * 6, 64 * 8, 64, 64);

	dodge_ = asset.LoadSprite("Resources/Images/Control/Dodge.png");
	dodge_->SetSize(dodgeUIData_.size);
	dodge_->SetPosition(dodgeUIData_.pos);
}

void UIDrawer::Update() {
	auto& ctx = GameContext::GetInstance();
	auto& input = ctx.Input();

	if (input.gamepad.IsConnected()) {
		if (input.keyboard.IsRelease(DIK_F)) { UpdatePlayerUI(); }
	} else {
		if (input.gamepad.IsRelease(XINPUT_GAMEPAD_A)) { UpdatePlayerUI(); }
	}

	// hp
	float hpRate = player_->GetHP() / player_->GetMaxHP();
	life_->SetTextureRect(0, 0, hpRate * 290, 68);
	life_->SetSize({ hpRate * 290,68 });

	float hp = player_->GetHP();
	if (hp != whiteLife_) {
		if (hp >= whiteLife_) {
			whiteLife_ = hp;
		} else {
			whiteLife_ -= whiteGaugeSpeed_;
		}

		float preHPRate = whiteLife_ / player_->GetMaxHP();
		damage_->SetTextureRect(0, 0, preHPRate * 290, 68);
		damage_->SetSize({ preHPRate * 290,68 });
	}

	equipment_->Update();
	nextRoom_->Update();

	if (WorldWeapon* weapon = dynamic_cast<WorldWeapon*>(itemManager_->GetInteractive())) {
		weaponSummary_->Update(weapon->GetWeaponData());
	} else {
		weaponSummary_->Update();
	}
}

void UIDrawer::Draw() {
	auto& ctx = GameContext::GetInstance();
	auto& input = ctx.Input();
	auto& render = ctx.Render();

	nextRoom_->Draw();

	// プレイヤーUI
#pragma region PlayerUI
	// 操作
	render.DrawSprite(dodge_.get());
	if (input.gamepad.IsConnected()) {
		if (input.gamepad.IsPress(XINPUT_GAMEPAD_X)) {
			dodgeControlPad_->SetTextureRect(64 * 6, 64 * 8, 64, 64);
		} else {
			dodgeControlPad_->SetTextureRect(64 * 7, 64 * 8, 64, 64);
		}
		render.DrawSprite(dodgeControlPad_.get());
	} else {
		render.DrawSprite(dodgeControlKey_.get());
	}

	// hp
	render.DrawSprite(lifeBack_.get());
	render.DrawSprite(damage_.get());
	render.DrawSprite(life_.get());

#pragma endregion

	equipment_->Draw();
	money_->Draw();
	passive_->Draw();
	weaponSummary_->Draw();

}

void UIDrawer::UpdatePlayerUI() {
}

void UIDrawer::UpdateStageUI() {
}
