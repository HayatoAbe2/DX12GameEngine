#pragma once
class MoneyUI;

/// <summary>
/// 所持金の追加・消費
/// </summary>
class Wallet {
public:
	void Initialize(MoneyUI* ui);

	// 追加
	void Add(int amount);

	// 払う
	bool Pay(int amount);

 	int GetCurrentMoney() { return money_; }

private:
	static constexpr int kMaxMoney = 9999;

	int money_ = 50;

	MoneyUI* ui_;
};

