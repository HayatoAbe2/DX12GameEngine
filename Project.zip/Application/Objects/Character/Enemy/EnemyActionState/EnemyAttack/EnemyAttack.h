#pragma once
#include "Objects/Character/Enemy/Enemy.h"

/// <summary>
/// 攻撃と待ち時間待機
/// </summary>
class EnemyAttack : public EnemyActionState {
public:
	void Update(Enemy* enemy, Player* player, MapCheck* mapCheck, BulletManager* bulletManager) override;

private:
	// 攻撃モーション
	float attackMotionStart_ = 0.5f;
	float EaseIn(float start, float end, float t);

	// 方向転換
	Timer rotateTimer_;
	const float minRotateTimer_ = 0.5f;
	const float maxRotateTimer_ = 0.8f;
};


