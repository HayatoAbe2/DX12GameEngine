#include "Weapon.h"
#include "Objects/Character/Enemy/Enemy.h"
#include "Objects/Character/Player/Player.h"

Weapon::Weapon(const WeaponData& data, std::unique_ptr<Model> model, std::unique_ptr<Model> shadowModel) {
	data_ = data;
	charge_ = data_.stats.maxCharge;

	model_ = std::move(model);
	shadowModel_ = std::move(shadowModel);
}

float Weapon::Trigger(const Vector3& pos, const Vector2& dir, BulletManager* bulletManager, Character* from) {
	// 撃てない
	if (from->GetTeam() == Team::Player && charge_ < 1.0f) {
		return 0;
	}

	auto& ctx = GameContext::GetInstance();
	auto& asset = ctx.Asset();

	// 溜め(離して発射)
	if (data_.traits.charge) {
		data_.traits.charge->currentTime += ctx.GetDeltatime();
		data_.traits.charge->currentTime = (std::min)(data_.traits.charge->currentTime, data_.traits.charge->time);
		data_.traits.charge->charging = true;
		SpawnChargeEffect();
		canChange_ = false;
		return 0;
	}

	return Fire(pos, dir, bulletManager, from);
}

void Weapon::Update(const Vector3& pos, const Vector2& dir, BulletManager* bulletManager, Character* from, bool isPress) {
	reloadStartTimer_.Update();
	if (reloadStartTimer_.GetState() == TimerState::Finished) {
		float deltatime = GameContext::GetInstance().GetDeltatime();
		float chargeTime = data_.stats.chargeTime * data_.modifiers[int(ModifierStats::coolTime)].multiply;
		charge_ = (std::min)(data_.stats.maxCharge, charge_ + deltatime / chargeTime);
	}

	if (data_.traits.burst) {
		auto& current = data_.traits.burst->currentCount;
		auto& maxCount = data_.traits.burst->count;
		auto& timer = data_.traits.burst->timer;
		timer.Update();

		if (timer.GetState() == TimerState::Finished && current > 0 && current < maxCount) {
			// 方向は一度目のもので固定
			Fire(pos, data_.traits.burst->dir, bulletManager, from);
		}
	}

	if (data_.traits.charge) {

		if (!isPress && data_.traits.charge->charging) {
			data_.traits.charge->charging = false;
			chargeEffect_ = nullptr;
		}
		// チャージしていて離したら1回だけ発射 
		if (!data_.traits.charge->charging && data_.traits.charge->currentTime > 0.0f) {
			Fire(pos, dir, bulletManager, from);
			data_.traits.charge->currentTime = 0.0f;
			canChange_ = true;
		}

		if (chargeEffect_) {
			float rate = data_.traits.charge->currentTime / data_.traits.charge->time;
			Vector2 shootPos = ToXZ(pos) + dir * (model_->GetTransform().scale.x) + Vector2{ data_.bullet.radius, data_.bullet.radius };
			chargeEffect_->Update(shootPos, rate * chargeRatio_);
		}
	}

	// modifireリセット
	data_.modifiers[int(ModifierStats::coolTime)].multiply = 1.0f;
}

void Weapon::Draw() {
	if (chargeEffect_) {
		chargeEffect_->Draw();
	}
}

float Weapon::Fire(const Vector3& pos, const Vector2& dir, BulletManager* bulletManager, Character* from) {
	auto& ctx = GameContext::GetInstance();
	auto& asset = ctx.Asset();
	auto& audio = ctx.Audio();

	// バースト射撃
	if (data_.traits.burst) {
		auto& current = data_.traits.burst->currentCount;
		auto& maxCount = data_.traits.burst->count;
		current++;
		data_.traits.burst->dir = dir;

		if (current < maxCount) {
			// 追加射撃の予約
			data_.traits.burst->timer.Start(data_.traits.burst->interval);
			canChange_ = false;
		} else {
			// 終了
			current = 0;
			canChange_ = true;
		}
	}

	Vector2 shootPos = ToXZ(pos) + dir * (model_->GetTransform().scale.x + data_.bullet.radius);

	// 複数弾
	if (data_.traits.multiShot && data_.traits.multiShot->count > 1) {
		int count = data_.traits.multiShot->count;
		// 度からラジアンに変換
		float maxAngle = data_.traits.multiShot->maxAngle * std::numbers::pi_v<float> / 180.0f;

		if (!data_.traits.multiShot->random) {
			// 角度の間隔
			float step = maxAngle / float(count - 1);

			for (int i = 0; i < count; ++i) {
				float angle = -maxAngle * 0.5f + step * i;
				float cos = std::cos(angle);
				float sin = std::sin(angle);
				Vector2 rotatedDir{
					dir.x * cos - dir.y * sin,
					dir.x * sin + dir.y * cos
				};

				// 弾生成
				std::unique_ptr<Bullet> bullet = std::make_unique<Bullet>(shootPos, rotatedDir, data_.bullet, from);
				// BulletManagerの管理下に移動
				bulletManager->AddBullet(std::move(bullet));
			}
		}

	} else {

		// 弾生成
		std::unique_ptr<Bullet> bullet = std::make_unique<Bullet>(shootPos, dir, data_.bullet, from);

		if (data_.traits.charge) {
			float rate = data_.traits.charge->currentTime / data_.traits.charge->time;
			bullet->GetData().damage += data_.traits.charge->damage * rate;
			bullet->GetData().radius += rate * chargeRatio_;
		}

		// BulletManagerの管理下に移動
		bulletManager->AddBullet(std::move(bullet));
	}

	// 効果音
	audio.SoundPlay(L"Resources/Sounds/SE/shoot.mp3", false);

	// プレイヤーが撃った場合のみ処理
	if (from->GetTeam() == Team::Player) {
		charge_--;
		charge_ = (std::max)(charge_, 0.0f);
		SetChargeStartTimer();

		// カメラシェイク
		ctx.Render().GetCamera()->StartShake(0.2f, 2);
	}

	return data_.stats.shootCoolTime;
}

void Weapon::SetChargeStartTimer() {
	// 回復開始までの時間
	reloadStartTimer_.Start(0.75f);
}

void Weapon::SpawnChargeEffect() {
	if (chargeEffect_) { return; }
	chargeEffect_ = std::make_unique<ChargeEffect>(data_.bullet.color);
}