#pragma once
#include "GameCommon.h"
#include "WeaponStatus.h"
#include "Objects/Character/Character.h"
#include "Timer/Timer.h"
#include "Objects/Bullet/Bullet.h"
#include "Objects/Item/Item.h"
#include "Effect/Charge/ChargeEffect.h"

class BulletManager;

/// <summary>
/// 武器
/// </summary>
class Weapon : public Item {
public:
	Weapon(const WeaponData& data, std::unique_ptr<Model> model, std::unique_ptr<Model> shadowModel);
	~Weapon() = default;

	// 発射入力されたときの処理
	float Trigger(const Vector3& pos, const Vector2& dir, BulletManager* bulletManager, Character* from);
	void Update(const Vector3& pos, const Vector2& dir, BulletManager* bulletManager, Character* from, bool isPress = false);
	void Draw();

	Model* GetModel() { return model_.get(); }
	Model* GetShadowModel() { return shadowModel_.get(); }

	// ステータス(強化分)
	std::array<ModifierValue, size_t(ModifierStats::count)>& GetModifier() { return data_.modifiers; }

	// データ(基礎数値)
	const WeaponData& GetData() const { return data_; }
	
	float GetCharge() { return charge_; }
	bool CanChange() { return canChange_; }

private:
	// 弾の発射
	float Fire(const Vector3& pos, const Vector2& dir, BulletManager* bulletManager, Character* from);
	void SetChargeStartTimer();
	// 溜めエフェクト
	void SpawnChargeEffect();

	WeaponData data_;
	std::unique_ptr<Model> model_;
	std::unique_ptr<Model> shadowModel_;

	Timer reloadStartTimer_;
	float charge_ = 0;

	bool canChange_ = true;

	// チャージショット用パーティクル
	std::unique_ptr<ChargeEffect> chargeEffect_;
	float chargeRatio_ = 2.0f;
};

