#pragma once
#include "Bullet.h"
#include "GameCommon.h"

class MapCheck;
class EffectManager;

/// <summary>
/// 弾の更新・描画
/// </summary>
class BulletManager {
public:
	void Update(MapCheck* mapCheck, EffectManager* effectManager, DamageAreaManager* damageAreaManager);
	void Draw(Camera* camera);
	void Reset();

	// 弾の追加(発射)
	void AddBullet(std::unique_ptr<Bullet> newBullet);
	std::vector<Bullet*> GetBullets();
private:
	// 弾
	std::vector<std::unique_ptr<Bullet>> bullets_;
};

