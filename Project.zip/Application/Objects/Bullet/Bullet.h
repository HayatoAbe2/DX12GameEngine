#pragma once
#include "GameCommon.h"
#include "Objects/Weapon/WeaponStatus.h"
#include <memory>
#include <Timer/Timer.h>
#include "Effect/EffectManager.h"
#include "Objects/DamageArea/DamageAreaManager.h"
#include <Objects/Character/Character.h>
#include <HitboxDisplay/HitboxDisplay.h>

class MapCheck;

/// <summary>
/// 発射された弾
/// </summary>
class Bullet {
public:
	Bullet(const Vector2& pos, const Vector2& direction, const BulletData& data, Character* from);
	~Bullet() = default;
	void Update(MapCheck* mapCheck, EffectManager* effectManager, DamageAreaManager* damageAreaManager);
	void Draw(Camera* camera);
	void Hit();

	Team GetTeam() { return user_->GetTeam(); }
	const Circle& GetCollider() const { return collider_; }
	BulletData& GetData() { return data_; }
	float GetDamage() { return data_.damage; }
	float GetKnockback() { return data_.knockback; }
	bool IsDead() { return isDead_; }
	bool CanErase() { return canErase_; }
	Vector2 GetPrePos() { return prePos_; }
	bool CanHit() { return !noHitTimer_.IsActive(); }

	void OnHitWall(EffectManager* effectManager, DamageAreaManager* damageAreaManager);
	void OnHitAnything(EffectManager* effectManager, DamageAreaManager* damageAreaManager);
private:
	// 移動の処理
	void Move(MapCheck* mapCheck, EffectManager* effectManager, DamageAreaManager* damageAreaManager);

	// 弾ステータス
	BulletData data_;

	// 衝突判定
	Circle collider_;
	// ヒット範囲表示
	std::unique_ptr<HitboxDisplay> hitboxDisplay_;

	// 前フレーム座標
	Vector2 prePos_{};
	// 速度
	Vector2 velocity_{};
	// 生存時間
	int lifeTime_ = 0;

	// 死亡フラグ(判定やめる)
	bool isDead_ = false;
	// 弾リストから削除可能
	bool canErase_ = false;

	// 無敵時間(ヒットした敵に一定時間当たらないリストに変更予定)
	std::vector<Character*> hitTargets_;
	Timer noHitTimer_;
	float invinsibleTime_ = 0.15f;

	// 射撃者
	Character* user_ = nullptr;

	// パーティクル
	std::unique_ptr<ParticleSystem> particle_;
	const int particleNum_ = 150;
	float particleRange_ = 0.7f;

	std::unique_ptr<ParticleSystem> hitParticle_;
	const int hitParticleNum_ = 10;
	float hitParticleRange_ = 1.0f;
	int hitParticleLifeTime = 20;

	std::unique_ptr<ParticleField> particleField_;
};

