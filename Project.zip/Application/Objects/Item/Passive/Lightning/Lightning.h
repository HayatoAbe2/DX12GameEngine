#pragma once
#include "Objects/Item/Passive/Passive.h"

/// <summary>
/// 連鎖攻撃
/// </summary>
class Lightning final : public Passive{
public:
	Lightning(std::unique_ptr<Sprite> sprite, std::unique_ptr<Sprite> explain, PassiveContext ctx);
	void OnDealDamage(const Vector2& pos) override;
};

