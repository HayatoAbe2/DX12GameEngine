#include "Counter.h"

Counter::Counter(std::unique_ptr<Sprite> sprite, std::unique_ptr<Sprite> explain, PassiveContext ctx) : Passive(std::move(sprite), std::move(explain), ctx) {
}

void Counter::OnHit(const Vector2& pos, Character* from) {
	auto& ctx = GameContext::GetInstance();
	auto& asset = ctx.Asset();
	auto& audio = ctx.Audio();

	// 弾データ
	BulletData data;
	data.damage = 6.0f;
	data.radius = 0.5f;
	data.speed = 30;
	data.lifeTime = 60;
	data.knockback = 0.3f;
	data.color = {0.5f,0.5f,0.5f,0.8f};

	int count = 8;
    for (int i = 0; i < count; i++) {
        float angle = (2.0f * std::numbers::pi_v<float> / count) * i;
        Vector2 shotDir = {cosf(angle), sinf(angle)};

		// 弾生成
        std::unique_ptr<Bullet> newBullet = std::make_unique<Bullet>(pos, shotDir, data, from);
        passiveCtx_.bulletManager->AddBullet(std::move(newBullet));
    }
}
