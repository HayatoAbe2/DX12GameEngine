#pragma once
#include "GameCommon.h"
#include "Objects/Item/World/WorldItem.h"
#include "Objects/Item/World/Chest/Chest.h"
#include "Rarity.h"
#include "Map/Room/RoomData.h"
#include <unordered_set>

class Player;
class WeaponManager;
class EnemyManager;
class BulletManager;
class Camera;

/// <summary>
/// ドロップしたアイテムの管理
/// </summary>
class ItemManager {
public:
	void Initialize(WeaponManager* weaponManager, EnemyManager* enemyManager, BulletManager* bulletManager);
	void Update(Player* player, RoomState roomState);
	void Draw();

	// 近くのアイテムにインタラクト
	void Interact(Player* player);

	// 新しく出現させる
	void SpawnWeapon(Vector3 pos,int index,Rarity rarity, bool isForSale);
	void SpawnMoney(Vector3 pos,int amount);
	void SpawnPassive(Vector3 pos, bool isForSale);

	// 持っていたものを落とす
	void Drop(Vector3 pos,std::unique_ptr<Weapon> weapon);

	// 配置リセット
	void Reset();

	// 次フレームに武器を配置(描画段階での生成をしないため)。名前は WeaponManager::GetWeaponNames() のもの
	void SetSpawn(Vector3 pos, const std::string& weaponName);

	// シーンを見て配置
	void Load();

	// インタラクト中のアイテム
	WorldItem* GetInteractive() { return interactive_; }

	// 報酬セット
	void SetReward(const RewardPlan& reward) { reward_ = reward; }
	
private:
	// 宝箱からの出現
	void ChestItemDrop(Chest* chest);

	// 部屋状態
	RoomState prevRoomState_;

	std::unique_ptr<Sprite> controlKey_ = nullptr;
	std::unique_ptr<Sprite> controlPad_ = nullptr;
	WeaponManager* weaponManager_ = nullptr;
	EnemyManager* enemyManager_ = nullptr;
	BulletManager* bulletManager_ = nullptr;

	// 落ちているアイテム
	std::vector<std::unique_ptr<WorldItem>> items_;
	std::vector<std::unique_ptr<Chest>> chests_;

	// インタラクト対称
	WorldItem* interactive_ = nullptr;
	const float kInteractRange = 2.0f; // インタラクト範囲

	std::vector<bool> weaponSpawned_;
	std::vector<bool> weaponSaleSpawned_;
	std::vector<bool> passiveSpawned_;
	std::vector<bool> passiveSaleSpawned_;

	// 次フレームに配置する武器の予約(同じフレームに複数押されても全部出す)
	struct WeaponSpawnRequest {
		Vector3 pos;
		std::string name;
	};
	std::vector<WeaponSpawnRequest> weaponSpawnRequests_;

	std::unordered_set<int> usedPassiveNumbers_;
	std::unordered_set<int> pickedPassiveNumbers_;

	// 報酬
	RewardPlan reward_;
};
 
