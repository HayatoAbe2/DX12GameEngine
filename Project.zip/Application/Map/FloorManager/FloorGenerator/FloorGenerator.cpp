#include "FloorGenerator.h"

Room* FloorGenerator::GenerateFloor(const FloorConfig& config) {
	// 最初の部屋
	Room first;
	first.type = RoomType::Start;
	first.startDirection = Direction::South;

	floor_ = first;
	return &floor_;
}

void FloorGenerator::EnsureNextRooms(Room& room, int depth, const FloorConfig& config) {
	const int nextDepth = depth + 1;
	if (nextDepth > config.goalDepth) {
		return; // ゴールの先はない
	}

	auto& ctx = GameContext::GetInstance();
	while (room.nextRooms.size() < 3) { // 3部屋接続
		Room next;

		// ゴール → 固定 → ランダムの順に決める。ランダムは、直前の部屋(room)と同じタイプの連続を補正する
		next.type = config.RoomTypeAt(nextDepth, room.type, ctx.RandomFloat(0.0f, 1.0f));
		room.nextRooms.push_back(std::move(next));
	}
}

RoomType FloorGenerator::SelectRoomType() {
	auto& ctx = GameContext::GetInstance();
	float r = (ctx.RandomFloat(0, 100));
	if (r < 80) {
		return RoomType::Combat;
	} else if (r < 15) {
		return RoomType::Elite;
	} else {
		return RoomType::Shop;
	}
}

void FloorGenerator::LoadRoom(Room* room, Direction enterDir) {
	auto& ctx = GameContext::GetInstance();
	auto& scene = ctx.Scene();

	int num = ctx.RandomInt(1, int(roomNumberRange[int(room->type)]));
	std::string roomName;
	switch (room->type) {
	case RoomType::Start:
		roomName = "startRoom";
		break;

	case RoomType::Combat:
		roomName = "combatRoom";
		break;

	case RoomType::Elite:
	case RoomType::Boss:
		roomName = "bossRoom";
		break;

	case RoomType::Shop:
		roomName = "shopRoom";
		break;

	case RoomType::Event:
		roomName = "eventRoom";
		break;

	case RoomType::Goal:
		roomName = "goalRoom";
	}

	room->connector.clear();
	room->startDirection = GetOpposite(enterDir);
	room->startPos = {};

	// 部屋生成
	scene.SceneLoad("Resources/Debug/SceneEditor/" + roomName + std::to_string(num) + ".json");

	// 接続箇所を検索
	std::vector<Model*> models;
	for (auto& obj : scene.GetCurrentScene()->GetObjects()) {
		if (dynamic_cast<Model*>(obj)) {
			auto* model = dynamic_cast<Model*>(obj);
			models.push_back(model);
		}
	}

	// 出入口
	for (auto& model : models) {
		if (model->tag == "westConnector" ||
			model->tag == "eastConnector" ||
			model->tag == "southConnector" ||
			model->tag == "northConnector") {
			auto transform = model->GetTransform();

			// 出入口の方向
			Direction dir = Direction::North; // 初期値
			auto it = exitDir.find(model->tag);
			if (it != exitDir.end()) {
				dir = it->second;
			}

			if (dir == room->startDirection) {
				// スタート地点には出口を作らない
				room->startPos = ToXZ(transform.translate);
				continue;
			} else if (room->startPos.x == 0 && room->startPos.y == 0) {
				room->startPos = ToXZ(transform.translate);
			}

			// 出入口を作成
			if (room->connector.size() < room->nextRooms.size()) {
				RoomConnector connector;
				connector.collider = { ToXZ(transform.translate - transform.scale * 0.5f), ToXZ(transform.translate + transform.scale * 0.5f) };
				connector.connectedRoom = &room->nextRooms[room->connector.size()];
				connector.direction = dir;
				room->connector.push_back(connector);
			}
		}
	}
}