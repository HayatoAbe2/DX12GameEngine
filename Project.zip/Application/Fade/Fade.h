#pragma once
#include "GameCommon.h"
#include "Timer/Timer.h"

const float kMaxFadeinTimer_ = 0.5f;
const float kMaxFadeoutTimer_ = 0.5f;

/// <summary>
/// フェードの段階
/// </summary>
enum class FadePhase {
	None,
	FadeOut,
	Faded,
	FadeIn
};

/// <summary>
/// フェード演出
/// </summary>
class Fade {
private:
	FadePhase fadePhase_ = FadePhase::None;
public:
	Fade();
	void Update();
	void Draw();

	// 開始
	void StartFadeIn(float seconds = kMaxFadeinTimer_);
	void StartFadeOut(float seconds = kMaxFadeoutTimer_);

	// フェード中
	bool IsActive() { return timer_.GetState() == TimerState::Running; }
	FadePhase GetPhase() { return fadePhase_; }

private:
	Timer timer_;
	float maxTime_ = kMaxFadeinTimer_;

	bool isFinished_ = false;

	std::unique_ptr<Sprite> sprite_;

};

