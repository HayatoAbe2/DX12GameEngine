#include "GameScene.h"
#include "Map/FloorSetting.h"
#include "Data/RoomPlanSerializer.h"
#include <numbers>

GameScene::~GameScene() {
}

void GameScene::Initialize() {
	auto& ctx = GameContext::GetInstance();
	auto& asset = ctx.Asset();
	auto& render = ctx.Render();

	debugCamera_ = std::make_unique<DebugCamera>();
	debugCamera_->Initialize();
	camera_ = std::make_unique<Camera>();
	camera_->transform_.rotate = { 1.0f,0,0 };
	render.SetCamera(camera_.get());

	LoadSound();

	// Skybox
	skybox_ = asset.LoadTexture("Resources/Debug/Sky/skybox.dds");

	// タイル
	mapTile_ = std::make_unique<MapTile>();
	mapTile_->Initialize();

	// 確率
	randomSettings_ = std::make_unique<RandomSettings>();

	// フロア生成
	floorManager_ = std::make_unique<FloorManager>();

	// 弾
	bulletManager_ = std::make_unique<BulletManager>();

	// ダメージエリア
	damageAreaManager_ = std::make_unique<DamageAreaManager>();

	// 敵
	enemyManager_ = std::make_unique<EnemyManager>(floorManager_.get());

	// 武器マネージャー
	weaponManager_ = std::make_unique<WeaponManager>();
	weaponManager_->Initialize();

	// アイテムマネージャー
	itemManager_ = std::make_unique<ItemManager>();
	itemManager_->Initialize(weaponManager_.get(), enemyManager_.get(), bulletManager_.get());

	// プレイヤー
	player_ = std::make_unique<Player>();
	player_->Initialize(itemManager_.get());
	player_->SetWeapon(weaponManager_->GetWeapon(0));

	// エフェクト
	effectManager_ = std::make_unique<EffectManager>();
	effectManager_->Initialize();

	// 当たり判定
	collisionSystem_ = std::make_unique<CollisionSystem>(effectManager_.get(), bulletManager_.get(), damageAreaManager_.get(), enemyManager_.get(), camera_.get());

	// フェード
	fade_ = std::make_unique<Fade>();

	// リザルト
	result_ = std::make_unique<Result>(fade_.get());

	// マップ判定
	mapCheck_ = std::make_unique<MapCheck>(mapTile_->GetMap(), mapTile_->GetTileSize());
	mapTile_->UpdateMapChange(enableEditMode_);
	Reset();

	// マップ生成より後
	SetupFloor();

	isLoaded_ = false;

	player_->Update(mapCheck_.get(), camera_.get(), bulletManager_.get());

	// UI描画システム
	uiDrawer_ = std::make_unique<UIDrawer>(player_.get(), floorManager_.get(), itemManager_.get());

	// エディタ
	spawnEditor_ = std::make_unique<SpawnRateEditor>();
	enemyEditor_ = std::make_unique<EnemyEditor>();
	weaponEditor_ = std::make_unique<WeaponEditor>();
	floorEditor_ = std::make_unique<FloorEditor>();

	Update();

	weaponEditor_->SetOnApplied([this] { weaponManager_->Reload(); });
	enemyEditor_->SetOnApplied([this] { enemyManager_->ReloadEnemyData(); });
	floorEditor_->SetOnApplied([this] { floorManager_->ReloadConfig(); });
	floorEditor_->SetOnRegenerate([this] { regenerateFloorRequested_ = true; });

	// エディタの「出す」ボタン(保存して出す場合も、保存で再読み込みされた後に呼ばれる)
	weaponEditor_->SetOnSpawn([this](const std::string& name) {
		itemManager_->SetSpawn(player_->GetTransform().translate, name);
	});
	enemyEditor_->SetOnSpawn([this](const std::string& name) {
		enemyManager_->RequestSpawn(GetDebugEnemySpawnPos(), weaponManager_.get(), name);
	});
}

void GameScene::Update() {
	auto& ctx = GameContext::GetInstance();
	auto& input = ctx.Input();
	auto& audio = ctx.Audio();
	auto& scene = ctx.Scene();

	// フロアエディタからの作り直し
	if (regenerateFloorRequested_ && phase_ == Phase::GAME) {
		regenerateFloorRequested_ = false;
		RegenerateFloor();
	}

	switch (phase_) {
	case Phase::GAME:
		// フェードアウト終了時
		if (fade_->GetPhase() == FadePhase::Faded) {
			if (player_->IsDead() || floorManager_->GetCurrentDepth() == floorManager_->GetMaxDepth()) {
				// リザルト移行
				phase_ = Phase::RESULT;
				fade_->StartFadeIn();
			} else if (isRoomMoving_) {
				// 次の部屋
				MoveToNextRoom(nextDirection_);

				isRoomMoving_ = false;
			} else {
				// 次のフロア
				Reset();
				Initialize();

				fade_->StartFadeIn();
			}
			break;
		}

		if (!enableEditMode_) {
			if (isPause_) {
				// ポーズ中
				if (input.keyboard.IsRelease(DIK_ESCAPE) || input.gamepad.IsPress(XINPUT_GAMEPAD_START)) {
					isPause_ = false;
				}

			} else {

				if (!fade_->IsActive() && fade_->GetPhase() == FadePhase::None) {
					// プレイヤー処理
 					player_->Update(mapCheck_.get(), camera_.get(), bulletManager_.get());

					// ゲームオーバー
					if (player_->IsDead()) {
						fade_->StartFadeOut(1.5f);
					}

					// ゴール判定
					Vector2 pos = { player_->GetTransform().translate.x,player_->GetTransform().translate.z };
					if (mapCheck_->IsGoal(pos, player_->GetRadius(), enemyManager_->GetEnemies().size() == 0)) {
						fade_->StartFadeOut();
						audio.SoundPlay(L"Resources/Sounds/SE/warp.mp3", false);
					}

					// 次の部屋移動判定
					for (auto& connector : floorManager_->GetConnector()) {
						if (CheckCollision(ToXZ(player_->GetTransform().translate), connector.collider)) {
							fade_->StartFadeOut();
							isRoomMoving_ = true;
							nextDirection_ = connector.direction;
						}
					}
				}

				// カメラ追従
				camera_->transform_.translate = player_->GetTransform().translate + Vector3{ 0,30,-19 };

				// 敵
				if (!enableEditMode_) {
					enemyManager_->Update(mapCheck_.get(), player_.get(), bulletManager_.get(), itemManager_.get());
					mapCheck_->SetRoomState(floorManager_->GetCurrentRoomState());
				}

				// 弾の処理
				bulletManager_->Update(mapCheck_.get(), effectManager_.get(), damageAreaManager_.get());

				// ダメージエリア処理
				damageAreaManager_->Update();
				
				// 衝突判定
				collisionSystem_->Update(player_.get(), mapCheck_.get());

				// アイテム
				itemManager_->Update(player_.get(), floorManager_->GetCurrentRoomState());

				// マップ
				mapTile_->UpdateMapChange(enableEditMode_);
				mapTile_->Update(enemyManager_->GetEnemies().size() == 0);
				mapCheck_->Update(mapTile_->GetMap());

				floorManager_->Update(enemyManager_.get());

				effectManager_->Update();

				uiDrawer_->Update();
			}
		}

		mapTile_->UpdateMapChange(enableEditMode_);
		enemyManager_->SpawnCheck(player_->GetTransform().translate, mapCheck_.get());

		if (enableEditMode_) {
			isLoaded_ = false;
		} else {
			// 編集の反映,再配置
			if (!isLoaded_) {
				itemManager_->SetReward(floorManager_->GetCurrentPlan().reward);
				itemManager_->Load();
				enemyManager_->Load(weaponManager_.get(), randomSettings_.get());
			}

			isLoaded_ = true;
		}
		
		break;
	case Phase::RESULT:
		result_->Update(floorManager_.get());
	}
}

void GameScene::Draw() {
	BaseScene::Draw();
	fade_->Update();

	// カメラ行列更新
	camera_->Update(debugCamera_.get());
	debugCamera_->Update();

	auto& ctx = GameContext::GetInstance();
	auto& light = ctx.Light();
	light.DrawLightImGui();
	auto& render = ctx.Render();
	if (phase_ == Phase::RESULT) {
		render.AddPostEffect(PostEffectType::Grayscale);
		render.AddPostEffect(PostEffectType::Vignette);
	} else {
		render.AddPostEffect(PostEffectType::Outline);
	}

	if (fade_->GetPhase() != FadePhase::None) {
		render.AddPostEffect(PostEffectType::RadialBlur);
	}
	render.DrawSkybox(skybox_.get()); // パーティクルを後に描画したい

	player_->Draw(camera_.get());
	enemyManager_->Draw();
	bulletManager_->Draw(camera_.get());
	itemManager_->Draw();
	effectManager_->Draw(camera_.get());

	// ui
	if (!enableEditMode_) {
		uiDrawer_->Draw();
	}

	// リザルト
	if (phase_ == Phase::RESULT) {
		result_->Draw();
	}

	fade_->Draw();

#ifdef USE_IMGUI
	spawnEditor_->Draw(enemyManager_->GetEnemyNames());
	floorEditor_->Draw();
	weaponEditor_->Draw();
	enemyEditor_->Draw(
		weaponManager_->GetEnemyAttackNames(),
		[this](const std::string& name) {
			return weaponManager_->GetEnemyAttackData(name);
		});
#endif
}

void GameScene::Reset() {
	auto& ctx = GameContext::GetInstance();
	auto& scene = ctx.Scene();

	scene.Reset();
	enemyManager_->Reset();
	itemManager_->Reset();
	bulletManager_->Reset();
	player_->Stop();

	// プレイヤー位置
	Vector3 pos = { floorManager_->GetStartPos().x, 0, floorManager_->GetStartPos().y };
	player_->SetTransform({ { 1,1,1 }, { 0,0,0 }, pos });

	isLoaded_ = false;
	mapCheck_->Reset(mapTile_->GetMap(), mapTile_->GetTileSize());
}

void GameScene::MoveToNextRoom(Direction direction) {
	Reset();
	fade_->StartFadeIn();

	// 次の部屋ロード
	floorManager_->LoadNextRoom(direction);
	// その次の部屋内容を用意する
	floorManager_->PlanNextRooms(randomSettings_.get());
	if (kSaveFloorPlan) { floorManager_->SaveFloorPlan(kFloorPlanPath); }

	// プレイヤー位置
	Vector3 pos = { floorManager_->GetStartPos().x, 0, floorManager_->GetStartPos().y };
	player_->SetTransform({ { 1,1,1 }, { 0,0,0 }, pos });
}

void GameScene::SetupFloor() {
	floorManager_->Initialize();

	// 予定ファイルの内容を反映する(抽選より先に読む。ファイルにない部屋は、このあと抽選される)
	if (kLoadFloorPlan) {
		std::vector<DataIssue> issues;
		if (floorManager_->LoadFloorPlan(kFloorPlanPath, &issues)) {
			for (auto& issue : RoomPlanSerializer::ValidateTree(*floorManager_->GetRoot(), enemyManager_->GetEnemyNames())) {
				issues.push_back(std::move(issue));
			}
		}
		for (const auto& issue : issues) {
			OutputDebugStringA(((issue.isError ? "[FloorPlan error] " : "[FloorPlan warn] ") + issue.message + "\n").c_str());
		}
	}

	floorManager_->PlanNextRooms(randomSettings_.get());
	if (kSaveFloorPlan) { floorManager_->SaveFloorPlan(kFloorPlanPath); }
}

void GameScene::RegenerateFloor() {
	Reset();
	SetupFloor();

	// プレイヤー位置
	Vector3 pos = { floorManager_->GetStartPos().x, 0, floorManager_->GetStartPos().y };
	player_->SetTransform({ { 1,1,1 }, { 0,0,0 }, pos });
	isLoaded_ = false;
}

void GameScene::LoadSound() {
	auto& ctx = GameContext::GetInstance();
	auto& audio = ctx.Audio();

	audio.SoundLoad(L"Resources/Sounds/SE/explosion.mp3");
	audio.SoundLoad(L"Resources/Sounds/SE/shoot.mp3");
	audio.SoundLoad(L"Resources/Sounds/SE/fire.mp3");
	audio.SoundLoad(L"Resources/Sounds/SE/floorClear.mp3");
	audio.SoundLoad(L"Resources/Sounds/SE/fall.mp3");
	audio.SoundLoad(L"Resources/Sounds/SE/warp.mp3");
	audio.SoundLoad(L"Resources/Sounds/SE/hit.mp3");
}

void GameScene::SpawnForDebug() {
#ifdef USE_IMGUI
	// 一覧は読み込まれているデータから作る
	ImGui::Begin("Weapon");
	ImGui::DragFloat3("cameraPos", &camera_->transform_.translate.x, 0.5f);

	ImGui::SeparatorText("武器(プレイヤーの足元に出す)");
	ImGui::PushID("weapon");
	for (const std::string& name : weaponManager_->GetWeaponNames()) {
		if (ImGui::Button(name.c_str())) {
			itemManager_->SetSpawn(player_->GetTransform().translate, name);
		}
	}
	ImGui::PopID();

	ImGui::SeparatorText("敵(プレイヤーの近くに出す)");
	ImGui::PushID("enemy");
	for (const std::string& name : enemyManager_->GetEnemyNames()) {
		if (ImGui::Button(name.c_str())) {
			enemyManager_->RequestSpawn(GetDebugEnemySpawnPos(), weaponManager_.get(), name);
		}
	}
	ImGui::PopID();
	ImGui::End();
#endif
}

Vector3 GameScene::GetDebugEnemySpawnPos() const {
	// デバッグ出現する位置
	return player_->GetTransform().translate + Vector3{ 0.0f, 0.0f, 3.0f };
}