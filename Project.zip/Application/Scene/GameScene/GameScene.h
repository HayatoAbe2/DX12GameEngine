#pragma once
#include "Engine/Scene/BaseScene/BaseScene.h"

#include "Result/Result.h"
#include "Objects/Character/Player/Player.h"
#include "Objects/Character/Enemy/EnemyManager/EnemyManager.h"
#include "Objects/Bullet/BulletManager.h"
#include "Effect/EffectManager.h"
#include "Map/MapTile.h"
#include "Map/MapCheck.h"
#include "Objects/Weapon/WeaponManager/WeaponManager.h"
#include "Objects/Item/ItemManager.h"
#include "CollisionSystem/CollisionSystem.h"
#include "UI/UIDrawer/UIDrawer.h"
#include "Map/FloorManager/FloorManager.h"
#include "Fade/Fade.h"
#include "RandomSettings/RandomSettings.h"

#include "Editor/SpawnRateEditor/SpawnRateEditor.h"
#include <Editor/EnemyEditor/EnemyEditor.h>
#include <Editor/WeaponEditor/WeaponEditor.h>
#include "Editor/FloorEditor/FloorEditor.h"

// ゲームシーン
class GameScene final : public BaseScene {
public:

	~GameScene() override;

	// 初期化
	void Initialize() override;

	// 更新
	void Update() override;

	// 描画
	void Draw() override;

	// リセット
	void Reset();

	// 次の部屋に移動
	void MoveToNextRoom(Direction direction);

	// フロアを作る(設定を読み直し、最初の部屋と、その次の部屋の内容まで用意する)
	void SetupFloor();
	// 今の進行を捨てて、フロアを作り直す(フロアエディタから)
	void RegenerateFloor();

private:
	void LoadSound();
	void SpawnForDebug(); // デバッグ用の武器・敵の出現(読み込まれているデータの一覧から作る)
	Vector3 GetDebugEnemySpawnPos() const; // 敵を出す位置(プレイヤーの近く)

	enum class Phase {
		GAME,
		RESULT
	};
	Phase phase_ = Phase::GAME;
	std::unique_ptr<Result> result_;

	std::shared_ptr<Texture> skybox_ = nullptr;

	// プレイヤー
	std::unique_ptr<Player> player_ = nullptr;

	// 敵
	std::unique_ptr<EnemyManager> enemyManager_ = nullptr;

	// 弾
	std::unique_ptr<BulletManager> bulletManager_ = nullptr;

	// ダメージエリア
	std::unique_ptr<DamageAreaManager> damageAreaManager_ = nullptr;

	// エフェクト
	std::unique_ptr<EffectManager> effectManager_ = nullptr;

	// マップ
	std::unique_ptr<MapTile> mapTile_ = nullptr;

	// マップ判定
	std::unique_ptr<MapCheck> mapCheck_ = nullptr;

	// 武器マネージャー
	std::unique_ptr<WeaponManager> weaponManager_ = nullptr;

	// アイテムマネージャー
	std::unique_ptr<ItemManager> itemManager_ = nullptr;

	// 当たり判定
	std::unique_ptr<CollisionSystem> collisionSystem_ = nullptr;

	// 確率設定
	std::unique_ptr<RandomSettings> randomSettings_ = nullptr;

	// UI
	std::unique_ptr<UIDrawer> uiDrawer_ = nullptr;

	// カメラ
	std::unique_ptr<Camera> camera_ = nullptr;

	// デバッグカメラ
	std::unique_ptr <DebugCamera> debugCamera_ = nullptr;

	// ポーズ
	bool isPause_ = false;

	bool isLoaded_ = false;

	// フロア
	std::unique_ptr<FloorManager> floorManager_;
	bool isRoomMoving_ = false;
	Direction nextDirection_;

	// フェード
	std::unique_ptr<Fade> fade_ = nullptr;

	// エディタ
	std::unique_ptr<SpawnRateEditor> spawnEditor_ = nullptr;
	std::unique_ptr<EnemyEditor> enemyEditor_ = nullptr;
	std::unique_ptr<WeaponEditor> weaponEditor_ = nullptr;
	std::unique_ptr<FloorEditor> floorEditor_ = nullptr;

	// フロアエディタからの作り直し要求(描画の途中で生成しないよう、次の更新で行う)
	bool regenerateFloorRequested_ = false;
};
