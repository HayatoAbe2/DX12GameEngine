#include "ExplodeEffect.h"

ExplodeEffect::ExplodeEffect(const Vector3 pos, const Vector4 color, const float maxSize) : maxSize_(maxSize) {
	auto& ctx = GameContext::GetInstance();
	auto& asset = ctx.Asset();
	dome_ = asset.LoadModel("Resources/Models/HitEffect", "explode.obj");
	dome_->SetTranslate(pos);
	dome_->SetScale({});

	auto data = dome_->GetMaterial(0)->GetData();
	data.color = color;
	dome_->GetMaterial(1)->SetData(data);

	timer_.Start(duration_);
}

void ExplodeEffect::Update() {
	if (timer_.GetState() == TimerState::Running) {
		float x = 1.0f - timer_.GetRemaining() / duration_;
		// easeOutd
		size_ = Lerp(0.0f, maxSize_, 1.0f - powf(2.0f, -10.0f * x));

		dome_->SetScale({ size_, size_, size_ });
		auto data = dome_->GetMaterial(1)->GetData();
		Matrix4x4 rot = MakeRotateYMatrix(x * std::numbers::pi_v<float> * 2.0f);
		data.uvTransform = Multiply(MakeIdentity4x4(), rot);
		if (x > alphaStart_) {
			data.color.w = 1.0f - (x - alphaStart_) / (1.0f - alphaStart_) - 0.2f;
		} else {
			data.color.w = 0.8f;
		}
		dome_->GetMaterial(1)->SetData(data);

		timer_.Update();
	}
}

void ExplodeEffect::Draw(Camera* camera) {
	auto& render = GameContext::GetInstance().Render();
	render.DrawModel(dome_.get());
}
