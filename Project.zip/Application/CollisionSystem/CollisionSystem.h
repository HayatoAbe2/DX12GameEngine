#pragma once
#include <memory>
#include "CollisionChecker/CollisionChecker.h"

class Player;
class Camera;
class BulletManager;
class DamageAreaManager;
class EffectManager;
class MapCheck;

/// <summary>
/// 衝突判定を一括するクラス
/// </summary>
class CollisionSystem {
public:
	CollisionSystem(
		EffectManager* effectManager,
		BulletManager* bulletManager,
		DamageAreaManager* damageAreaManager,
		EnemyManager* enemyManager,
		Camera* camera);
	void Update(Player* player, MapCheck* mapCheck);

private:
	// 弾マネージャ
	BulletManager* bulletManager_;

	// ダメージエリアマネージャ
	DamageAreaManager* damageAreaManager_;

	// 敵マネージャ
	EnemyManager* enemyManager_;

	// 当たり判定
	std::unique_ptr<CollisionChecker> collisionChecker_ = nullptr;
};

