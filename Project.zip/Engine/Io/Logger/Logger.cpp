#include "Logger.h"
#include <Windows.h>
#include <filesystem>

Logger::Logger() {
	// 現在の出力ディレクトリ（exeの実行ディレクトリ）を取得
	std::filesystem::path outputDir = std::filesystem::current_path().parent_path();
	// logs フォルダを出力場所に作成
	std::filesystem::path logDir = outputDir / "generated" / "logs";
	if(std::filesystem::exists(logDir)){
	// ログのディレクトリを用意
	std::filesystem::create_directory(logDir);
	// 現在時刻を取得(UTC)
	std::chrono::system_clock::time_point now = std::chrono::system_clock::now();
	// ログファイルの名前にコンマ何秒はいらないので、削って秒にする
	std::chrono::time_point<std::chrono::system_clock, std::chrono::seconds>
		nowSeconds = std::chrono::time_point_cast<std::chrono::seconds>(now);
	// 日本時間(PCの設定時間)に変換
	std::chrono::zoned_time localTime{ std::chrono::current_zone(),nowSeconds };
	// formatを使って年月日_時分秒の文字列に変換
	std::string dateString = std::format("{:%Y%m%d_%H%M%S}", localTime);
	// 時刻を使ってファイル名を決定
	std::filesystem::path logFilePath = logDir / (dateString + ".log");
	// ファイルを作って書き込み準備
	logStream_.open(logFilePath);
	}
}

Logger::~Logger(){
	if (logStream_.is_open()) {
		logStream_.close();
	}
}

void Logger::Log(std::ostream& os, const std::string& message){
	os << message << std::endl;
	OutputDebugStringA(message.c_str());
}

// string->wstring
std::wstring Logger::ConvertString(const std::string& str) {
	if (str.empty()) {
		return std::wstring();
	}

	auto sizeNeeded = MultiByteToWideChar(CP_UTF8, 0, reinterpret_cast<const char*>(&str[0]), static_cast<int>(str.size()), NULL, 0);
	if (sizeNeeded == 0) {
		return std::wstring();
	}
	std::wstring result(sizeNeeded, 0);
	MultiByteToWideChar(CP_UTF8, 0, reinterpret_cast<const char*>(&str[0]), static_cast<int>(str.size()), &result[0], sizeNeeded);
	return result;
}

// wstring->string
std::string Logger::ConvertString(const std::wstring& str) {
	if (str.empty()) {
		return std::string();
	}

	auto sizeNeeded = WideCharToMultiByte(CP_UTF8, 0, str.data(), static_cast<int>(str.size()), NULL, 0, NULL, NULL);
	if (sizeNeeded == 0) {
		return std::string();
	}
	std::string result(sizeNeeded, 0);
	WideCharToMultiByte(CP_UTF8, 0, str.data(), static_cast<int>(str.size()), result.data(), sizeNeeded, NULL, NULL);
	return result;
}