#pragma once
#include "Engine/Math/MathUtils.h"
#include <string>
#include <vector>
#include <memory>

/// <summary>
/// モデルのノード
/// </summary>
struct ModelNode {
    QuaternionTransform transform;
	Matrix4x4 localMatrix;
	std::string name;
	std::vector<std::unique_ptr<ModelNode>> children;
	std::vector<int> meshIndices;

    ModelNode() = default;
    ~ModelNode() = default;

    // コピー禁止
    ModelNode(const ModelNode&) = delete;
    ModelNode& operator=(const ModelNode&) = delete;

    // ムーブ許可
    ModelNode(ModelNode&&) = default;
    ModelNode& operator=(ModelNode&&) = default;
};