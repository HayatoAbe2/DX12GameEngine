#pragma once
#include "Engine/Asset/Resource/Material/Material.h"
#include "Engine/Graphics/GPUData/VertexData.h"
#include "Engine/Graphics/GPUData/InstanceGPUData.h"
#include "Engine/Asset/Resource/Texture.h"
#include "Engine/SceneObject/Model/Mesh.h"
#include "Engine/SceneObject/Model/ModelData.h"
#include "Engine/SceneObject/Transform.h"
#include "Engine/Math/MathUtils.h"
#include "Engine/SceneObject/Model/Node.h"
#include "Engine/SceneObject/SceneObject.h"

#include <d3d12.h>
#include <wrl.h>
#include <vector>
#include <string>

class Renderer;
class Camera;
class BufferManager;
class ConstantBufferManager;

/// <summary>
/// インスタンシング描画用のモデル
/// </summary>
class InstancedModel final : public SceneObject {
public:
	InstancedModel(uint32_t id) : SceneObject(id) {};

	///
	/// モデル読み込み時のSetter
	///

	// インスタンス描画用
	int GetNumInstance() { return numInstance_; }
	void SetNumInstance(int numInstance) { numInstance_ = numInstance; }

	const D3D12_GPU_DESCRIPTOR_HANDLE& GetParticleSRVHandle() const { return instanceSRVHandleGPU_; }
	void SetSRVHandle(D3D12_GPU_DESCRIPTOR_HANDLE srvHandleGPU) { instanceSRVHandleGPU_ = srvHandleGPU; }

	const Microsoft::WRL::ComPtr<ID3D12Resource>& GetInstanceResource() const { return instanceTransformationResource_; }
	void SetInstanceResource(Microsoft::WRL::ComPtr<ID3D12Resource> resource) {
		instanceTransformationResource_ = resource;
	}

	void AddInstanceTransform() {
		transforms_.push_back({});
	}
	void SetTransforms(int index, const Transform& transform) {
		if (index < 0 || index >= numInstance_) return;
		transforms_[index] = transform;
	}
	void SetTransforms(std::vector<Transform> transforms) {
		transforms.resize(transforms_.size());
		transforms_ = transforms;
	}
	void SetScale(int index, const Vector3& scale) {
		if (index < 0 || index >= numInstance_) return;
		transforms_[index].scale = scale;
	}
	void SetRotate(int index, const Vector3& rotate) {
		if (index < 0 || index >= numInstance_) return;
		transforms_[index].rotate = rotate;
	}
	void SetTranslate(int index, const Vector3& translate) {
		if (index < 0 || index >= numInstance_) return;
		transforms_[index].translate = translate;
	}

	const std::vector<Transform>& GetTransforms() const { return transforms_; }
	void SetInstanceTransformData(InstanceGPUData* data) { instanceTransformationData_ = data; }
	const D3D12_GPU_VIRTUAL_ADDRESS GetInstanceCBV()const { return instanceTransformationResource_->GetGPUVirtualAddress(); }

	void UpdateInstanceTransform(Camera* camera, const std::vector<Transform>& transforms, std::vector<Vector4>& color);
	void UpdateInstanceTransformWithNode(Camera* camera, const Matrix4x4& nodeWorld, const std::vector<Vector4>& colors);

	// データの設定
	void CopyModelData(std::shared_ptr<ModelData> data, BufferManager* bufferManager, ConstantBufferManager* cBufferManager);

	// 根ノードを設定
	void SetRootNode(std::unique_ptr<ModelNode> rootNode) { rootNode_ = std::move(rootNode); }

	void SetDirectoryPath(std::string directoryPath) { directory_ = directoryPath; }


	// データの取得
	std::shared_ptr<ModelData> GetData() { return data_; }

	// マテリアル
	Material* GetMaterial(int index) { return material_[index].get(); }

	// rootNode取得
	ModelNode* GetRootNode() { return rootNode_.get(); }

	const std::string& GetDirectoryPath() { return directory_; }

private:

	// モデルデータ
	std::shared_ptr<ModelData> data_ = nullptr;

	// マテリアル
	std::vector<std::unique_ptr<Material>> material_{};

	// 根ノード
	std::unique_ptr<ModelNode> rootNode_{};

	// 複数体描画用（必要なときだけ使う）
	int numInstance_ = 1;
	D3D12_GPU_DESCRIPTOR_HANDLE instanceSRVHandleGPU_;
	std::vector<Transform> transforms_;
	Microsoft::WRL::ComPtr<ID3D12Resource> instanceTransformationResource_ = nullptr;
	InstanceGPUData* instanceTransformationData_ = nullptr;

	std::string directory_;
};

