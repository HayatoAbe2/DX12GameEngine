#include "SRVManager.h"
#include "Engine/Graphics/Core/DescriptorHeapManager/DescriptorHeapManager.h"
#include <cassert>

void SRVManager::Initialize(DescriptorHeapManager* descHeapManager, ID3D12Device* device) {
	descHeapManager_ = descHeapManager;
	device_ = device;

	// SRV用ヒープ
	descriptorHeap_ = descHeapManager->CreateDescriptorHeap(device_, D3D12_DESCRIPTOR_HEAP_TYPE_CBV_SRV_UAV, kMaxSRVCount_, true);

	// Descriptor1個のサイズ
	descriptorSize_ = device->GetDescriptorHandleIncrementSize(D3D12_DESCRIPTOR_HEAP_TYPE_CBV_SRV_UAV);
}

void SRVManager::PreDraw(const Microsoft::WRL::ComPtr<ID3D12GraphicsCommandList>& commandList) {
	// 描画用DescriptorHeapの設定
	ID3D12DescriptorHeap* descriptorHeaps[] = { descriptorHeap_.Get() };
	commandList->SetDescriptorHeaps(1, descriptorHeaps);
}

uint32_t SRVManager::Allocate() {
	// フリーリストに空きがあれば再利用
	if (!freeList_.empty()) {
		uint32_t idx = freeList_.back();
		freeList_.pop_back();
		return idx;
	}

	assert(useIndex_ < kMaxSRVCount_);

	// 現在インデックスを返す
	int index = useIndex_;
	useIndex_++;
	return index;
}

void SRVManager::Free(uint32_t index) {
	// 範囲チェック
	if (index >= kMaxSRVCount_) return;
	// ここで重複解放検出などが必要なら追加
	freeList_.push_back(index);
}

void SRVManager::CreateTextureSRV(uint32_t srvIndex, ID3D12Resource* pResource, DXGI_FORMAT format, UINT mipLevels, bool isCubemap) {
	// metaDataを基にSRVの設定
	D3D12_SHADER_RESOURCE_VIEW_DESC srvDesc{};
	srvDesc.Format = format;
	srvDesc.Shader4ComponentMapping = D3D12_DEFAULT_SHADER_4_COMPONENT_MAPPING;

	if (isCubemap) {
		srvDesc.ViewDimension = D3D12_SRV_DIMENSION_TEXTURECUBE;
		srvDesc.TextureCube.MostDetailedMip = 0;
		srvDesc.TextureCube.MipLevels = UINT_MAX;
		srvDesc.TextureCube.ResourceMinLODClamp = 0.0f;
	} else {
		srvDesc.ViewDimension = D3D12_SRV_DIMENSION_TEXTURE2D;
		srvDesc.Texture2D.MipLevels = mipLevels;
	}

	// SRVの生成
	device_->CreateShaderResourceView(pResource, &srvDesc, descHeapManager_->GetCPUDescriptorHandle(descriptorHeap_.Get(), descriptorSize_, srvIndex));
}

void SRVManager::CreateStructuredBufferSRV(uint32_t srvIndex, ID3D12Resource* pResource, UINT numElements, UINT structureByteStride) {
	D3D12_SHADER_RESOURCE_VIEW_DESC srvDesc{};
	srvDesc.Format = DXGI_FORMAT_UNKNOWN;
	srvDesc.Shader4ComponentMapping = D3D12_DEFAULT_SHADER_4_COMPONENT_MAPPING;
	srvDesc.ViewDimension = D3D12_SRV_DIMENSION_BUFFER;
	srvDesc.Buffer.FirstElement = 0;
	srvDesc.Buffer.Flags = D3D12_BUFFER_SRV_FLAG_NONE;
	srvDesc.Buffer.NumElements = numElements;
	srvDesc.Buffer.StructureByteStride = structureByteStride;

	// SRVの生成
	device_->CreateShaderResourceView(pResource, &srvDesc, descHeapManager_->GetCPUDescriptorHandle(descriptorHeap_.Get(), descriptorSize_, srvIndex));
}

void SRVManager::CreateRenderTextureSRV(uint32_t srvIndex, Microsoft::WRL::ComPtr<ID3D12Resource> renderTextureResource) {
	D3D12_SHADER_RESOURCE_VIEW_DESC renderTextureSrvDesc{};
	renderTextureSrvDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM_SRGB; // Resourceと同じ
	renderTextureSrvDesc.Shader4ComponentMapping = D3D12_DEFAULT_SHADER_4_COMPONENT_MAPPING;
	renderTextureSrvDesc.ViewDimension = D3D12_SRV_DIMENSION_TEXTURE2D;
	renderTextureSrvDesc.Texture2D.MipLevels = 1;

	device_->CreateShaderResourceView(renderTextureResource.Get(), &renderTextureSrvDesc, descHeapManager_->GetCPUDescriptorHandle(descriptorHeap_.Get(), descriptorSize_, srvIndex));
}

void SRVManager::CreateDepthSRV(uint32_t srvIndex, Microsoft::WRL::ComPtr<ID3D12Resource> depthStencilResource) {
	D3D12_SHADER_RESOURCE_VIEW_DESC depthTextureSrvDesc{};
	depthTextureSrvDesc.Format = DXGI_FORMAT_R24_UNORM_X8_TYPELESS;
	depthTextureSrvDesc.Shader4ComponentMapping = D3D12_DEFAULT_SHADER_4_COMPONENT_MAPPING;
	depthTextureSrvDesc.ViewDimension = D3D12_SRV_DIMENSION_TEXTURE2D;
	depthTextureSrvDesc.Texture2D.MipLevels = 1;

	device_->CreateShaderResourceView(depthStencilResource.Get(), &depthTextureSrvDesc, descHeapManager_->GetCPUDescriptorHandle(descriptorHeap_.Get(), descriptorSize_, srvIndex));
}

void SRVManager::CreateStructuredBufferUAV(uint32_t index, ID3D12Resource* pResource, UINT numElements, UINT structureByteStride) {
	D3D12_UNORDERED_ACCESS_VIEW_DESC uavDesc{};
	uavDesc.Format = DXGI_FORMAT_UNKNOWN;
	uavDesc.ViewDimension = D3D12_UAV_DIMENSION_BUFFER;
	uavDesc.Buffer.FirstElement = 0;
	uavDesc.Buffer.NumElements = numElements;
	uavDesc.Buffer.CounterOffsetInBytes = 0;
	uavDesc.Buffer.Flags = D3D12_BUFFER_UAV_FLAG_NONE;
	uavDesc.Buffer.StructureByteStride = structureByteStride;

	device_->CreateUnorderedAccessView(pResource, nullptr, &uavDesc, descHeapManager_->GetCPUDescriptorHandle(descriptorHeap_.Get(), descriptorSize_, index));
}

D3D12_CPU_DESCRIPTOR_HANDLE SRVManager::GetCPUHandle(uint32_t index) {
	return descHeapManager_->GetCPUDescriptorHandle(descriptorHeap_.Get(), descriptorSize_, index);
}

D3D12_GPU_DESCRIPTOR_HANDLE SRVManager::GetGPUHandle(uint32_t index) {
	return descHeapManager_->GetGPUDescriptorHandle(descriptorHeap_.Get(), descriptorSize_, index);
}