#include "AssetManager.h"

AssetManager::AssetManager(DirectXContext* dxContext, Logger* logger) :
	dxContext_(dxContext),
	logger_(logger),
	textureManager_(std::make_unique<TextureManager>(dxContext, logger)),
	modelManager_(std::make_unique<ModelManager>(dxContext, logger, textureManager_.get())),
	spriteManager_(std::make_unique<SpriteManager>(dxContext, logger, textureManager_.get())),
	animationManager_(std::make_unique<AnimationManager>()),
	particleManager_(std::make_unique<ParticleManager>(dxContext)) {
}

std::unique_ptr<Model> AssetManager::LoadModelFile(const std::string& directoryPath, const std::string& filename) {
	auto object = modelManager_->Load(GenerateID(), GenerateID(), GenerateID(), GenerateID(), directoryPath, filename);
	object->name = filename;
	return std::move(object);
}

std::unique_ptr<InstancedModel> AssetManager::LoadModelFile(const std::string& directoryPath, const std::string& filename, const int numInstance) {
	auto object = modelManager_->Load(GenerateID(), GenerateID(), GenerateID(), GenerateID(), directoryPath, filename, numInstance);
	object->name = filename;
	return std::move(object);
}

std::unique_ptr<ParticleSystem> AssetManager::CreateParticle(int numInstance) {
	return std::move(modelManager_->CreateParticleInstanceResource(numInstance, GenerateID()));
}
std::unique_ptr<ParticleSystem> AssetManager::CreateGPUParticle(int numInstance) {
	return std::move(particleManager_->CreateParticle(numInstance, GenerateID()));
}

std::unique_ptr<Primitive> AssetManager::CreatePrimitive(PrimitiveShape shape) {
	uint32_t id = GenerateID();
	auto object = modelManager_->CreatePrimitive(id);

	// 名前用配列
	std::string names[] = {
		"Plane",
		"Ring",
		"Cylinder"
	};
	object->name = names[int(shape)];

	return std::move(object);
}

std::unique_ptr<Sprite> AssetManager::LoadSprite(const std::string& filePath) {
	auto object = spriteManager_->Load(filePath, GenerateID(), GenerateID(), GenerateID());
	object->name = filePath;
	return std::move(object);
}

std::shared_ptr<Texture> AssetManager::LoadTexture(const std::string& filePath) {
	auto resource = textureManager_->Load(filePath, GenerateID());
	resource->name_ = filePath;
	return resource;
}

std::unique_ptr<Material> AssetManager::CreateMaterial(std::shared_ptr<Texture> texture) {
	auto resource = modelManager_->LoadMaterial(texture, GenerateID(), GenerateID());
	resource->name_ = texture->name_;
	return std::move(resource);
}

std::vector<std::shared_ptr<Animation>> AssetManager::LoadAnimation(const std::string& directoryPath, const std::string& filePath) {
	return animationManager_->Load(directoryPath, filePath, [this]() {return GenerateID(); });
}

std::unique_ptr<VideoPlayer> AssetManager::LoadVideo(const std::string& filePath, bool loop) {
	auto player = std::make_unique<VideoPlayer>(dxContext_, logger_, GenerateID());
	player->Open(filePath, loop); // 失敗しても返す。呼び出し側が IsOpen() で確認する
	return player;
}

std::unique_ptr<Sprite> AssetManager::LoadSprite(std::shared_ptr<Texture> texture) {
	auto object = spriteManager_->Create(texture, GenerateID(), GenerateID());
	object->name = "VideoSprite";
	return object;
}

uint32_t AssetManager::GenerateID() {
	return assetId_++;
}
