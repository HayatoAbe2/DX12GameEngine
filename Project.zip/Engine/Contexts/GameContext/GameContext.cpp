#include "GameContext.h"
#include "Engine/Graphics/Renderer/Renderer.h"
#include "Engine/Io/AudioSystem/AudioSystem.h"
#include "Engine/Io/InputSystem/InputSystem.h"
#include "Engine/Asset/Manager/AssetManager/AssetManager.h"
#include "Engine/SceneObject/LightManager/LightManager.h"
#include "Engine/Graphics/Utility/FixFPS/FixFPS.h"

GameContext::GameContext(Renderer* renderer, AudioSystem* audio, InputSystem* input, AssetManager* assetManager, LightManager* lightManager, SceneManager* sceneManager, SceneEditor* sceneEditor, FixFPS* fixFps) :
	asset_(std::make_unique<AssetContext>(assetManager)),
	audio_(std::make_unique<AudioContext>(audio)),
	input_(std::make_unique<InputContext>(input)),
	light_(std::make_unique<LightContext>(lightManager)),
	render_(std::make_unique<RenderContext>(renderer, lightManager)),
	scene_(std::make_unique<SceneContext>(sceneManager, sceneEditor)) {

	std::mt19937 randomEngine(randomDevice_());
	randomEngine_ = randomEngine;
	fixFps_ = fixFps;

	hwnd_ = input->GetHwnd();
	renderer_ = renderer;
}

Vector2 GameContext::GetWindowSize() const {
#ifdef USE_IMGUI
	return renderer_->GetSceneWindowSize();
#endif

	RECT rect;
	GetClientRect(hwnd_, &rect);
	return { float(rect.right),float(rect.bottom) };
}

Vector2 GameContext::GetRenderWindowSize() const {
	RECT rect;
	GetClientRect(hwnd_, &rect);
	return { float(rect.right),float(rect.bottom) };
}

#ifdef USE_IMGUI
bool GameContext::IsSceneWindowHovered() const {
	return renderer_->GetSceneWindowHovered();
}
#endif

float GameContext::GetDeltatime() const {
	return fixFps_->GetDeltatime();
}

int GameContext::RandomInt(int min, int max) {
	std::uniform_int_distribution<int> distribution(min, max);
	return distribution(randomEngine_);
}

float GameContext::RandomFloat(float min, float max) {
	std::uniform_real_distribution<float> distribution(min, max);
	return distribution(randomEngine_);
}