#pragma once
#include "Window.h"
#include "Engine/Io/DumpExporter/DumpExporter.h"
#include "Engine/Io/Logger/Logger.h"
#include "Engine/Io/AudioSystem/AudioSystem.h"
#include "Engine/Io/InputSystem/InputSystem.h"
#include "Engine/Contexts/GameContext/GameContext.h"
#include "Engine/Graphics/Core/DirectXContext/DirectXContext.h"
#include "Engine/Graphics/Renderer/Renderer.h"
#include "Engine/SceneObject/LightManager/LightManager.h"
#include "Engine/Scene/SceneManager/SceneManager.h"
#include "Engine/Asset/Manager/AssetManager/AssetManager.h"
#include "Editor/SceneEditor/SceneEditor.h"

#include <memory>
#include <Windows.h>
#include <dxgi1_6.h>
#include <dxgidebug.h>
#include <strsafe.h>
#include <wrl.h>

#pragma comment(lib,"d3d12.lib")	
#pragma comment(lib,"dxgi.lib")
#pragma comment(lib,"dxguid.lib")
#pragma comment(lib,"dxcompiler.lib")
#pragma comment(lib,"Dbghelp.lib")
#pragma comment(lib, "mf.lib")
#pragma comment(lib, "mfuuid.lib")

/// <summary>
/// アプリケーション全体の処理
/// </summary>
class App {
public:

	/// <summary>
	/// 初期化
	/// </summary>
	void Initialize();

	/// <summary>
	/// 処理
	/// </summary>
	void Run();

	/// <summary>
	/// 終了
	/// </summary>
	void Finalize();

private:
	struct D3DResourceLeakChecker {
		~D3DResourceLeakChecker() {
			// リソースリークチェック
			Microsoft::WRL::ComPtr<IDXGIDebug1> debug;
			if (SUCCEEDED(DXGIGetDebugInterface1(0, IID_PPV_ARGS(&debug)))) {
				debug->ReportLiveObjects(DXGI_DEBUG_ALL, DXGI_DEBUG_RLO_ALL);
				debug->ReportLiveObjects(DXGI_DEBUG_APP, DXGI_DEBUG_RLO_ALL);
				debug->ReportLiveObjects(DXGI_DEBUG_D3D12, DXGI_DEBUG_RLO_ALL);
			}

		}
	};
	std::unique_ptr<D3DResourceLeakChecker> leakCheck_ = nullptr;

	// ダンプファイル作成
	std::unique_ptr<DumpExporter> dumpExporter_ = nullptr;

	// ログの出力
	std::unique_ptr<Logger> logger_ = nullptr;

	// ウィンドウの作成
	std::unique_ptr<Window> window_ = nullptr;

	// 音声の出力
	std::unique_ptr<AudioSystem> audio_ = nullptr;

	// キー・コントローラー入力
	std::unique_ptr<InputSystem> input_ = nullptr;

	// DirectX管理
	std::unique_ptr<DirectXContext> dxContext_ = nullptr;

	// 描画
	std::unique_ptr<Renderer> renderer_ = nullptr;

	// リソース管理
	std::unique_ptr<AssetManager> assetManager_ = nullptr;

	// ライト管理
	std::unique_ptr<LightManager> lightManager_ = nullptr;

	// ゲームシーンから利用できるデータや関数
	std::unique_ptr<GameContext> gameContext_ = nullptr;

	// シーン管理
	std::unique_ptr<SceneManager> sceneManager_ = nullptr;

	// シーンエディタ
	std::unique_ptr<SceneEditor> sceneEditor_ = nullptr;
};


